# import arcpy, create workspace, run buffer tool found on RIGIS, set parameters
import arcpy
# ALL attributes written out
# roads = "majorrds"
# roadsBuffer = "C:/output/Output.gdb/buffer_output"
# distanceField = "Distance"
# sideType = "FULL"
# endType = "ROUND"
# dissolveType = "LIST"
# dissolveField = "Distance"
arcpy.env.workspace = r"C:\CodingChallenge4Ass4\Coastal_Wetlands_Designated_for_Preservation.cpg"
arcpy.Buffer_analysis("Coastal_Wetlands_Designated_for_Preservation", r"C:\CodingChallenge4Ass4\OutputBufferCHall4", "100 Feet", "FULL", "ROUND", "PLANAR", "NONE")
